package com.telegramtv.ui.player.audio

import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.tanh

/**
 * Playback-only PCM gain with a soft limiter. The source media is never modified.
 * Gain is applied after decoding, so the original compressed file remains untouched.
 */
@OptIn(UnstableApi::class)
class BoostAudioProcessor : BaseAudioProcessor() {
    @Volatile
    var boost: Float = 1f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val bytes = inputBuffer.remaining()
        val output = replaceOutputBuffer(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val input = inputBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val gain = boost.coerceIn(1f, 3f)
        if (gain == 1f) {
            output.put(input)
            inputBuffer.position(inputBuffer.limit())
            output.flip()
            return
        }
        while (input.remaining() >= 2) {
            val sample = input.short.toFloat()
            val x = sample / 32768f * gain
            val limited = if (abs(x) <= 0.9f) x else (tanh(x * 2.2f) / tanh(2.2f))
            output.putShort((limited.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        }
        inputBuffer.position(inputBuffer.limit())
        output.flip()
    }
}
